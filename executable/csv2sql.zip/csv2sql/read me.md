# How to run csv2sql

You must have mysql and erlang installed to run csv2sql...

## Add the erlang repository by..

```
wget https://packages.erlang-solutions.com/erlang-solutions_1.0_all.deb
sudo dpkg -i erlang-solutions_1.0_all.deb
```

## Install erlang

```
sudo apt-get update
sudo apt-get install esl-erlang
```

## Update configurations

cd into the directry with the configuration file and csv2sql executable 

Edit the ```config.env``` file according to your requirments.

## Load configurations

Load the configurations in ```config.env``` in your current shell session by ```source ./config.env```

## Start the app

Start csv2sql by ```./csv2sql```
